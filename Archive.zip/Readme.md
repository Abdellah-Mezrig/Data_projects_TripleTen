project "Storytelling with Data" Sprint 5

link for the project :https://public.tableau.com/views/project_sprint5_17442950078030/Story1?:language=en-US&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link

link for the presentation : https://drive.google.com/file/d/1cRgwaB86zwwgROcw41fA1ck_xoe69wbd/view?usp=sharing